# Lab 3

## Student information

* Minsoo Kim
* mkim410@ucr.edu
* mkim410
* 862238343

## Answers

- **(Q1)** Which of the following is the right way to call the `IsEven` function.

    - IsEven(5)
    - IsEven.apply(5)
    - new IsEven().apply(5)

      - new IsEven().apply(5) is the right way to call the `IsEven` function.

- **(Q2)** Did the program compile?
    - No, the program did not compile

- **(Q3)** If it does not work, what is the error message you get?
  - The error I got said `Variable used in lambda expression should be final or effectively final`, meaning I cannot change the value of `base` once it is set

