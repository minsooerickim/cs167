mvn package
java -cp target/mkim410_lab3-1.0-SNAPSHOT.jar edu.ucr.cs.cs167.mkim410.App 3 20 5
java -cp target/mkim410_lab3-1.0-SNAPSHOT.jar edu.ucr.cs.cs167.mkim410.App 3 20 3,5
java -cp target/mkim410_lab3-1.0-SNAPSHOT.jar edu.ucr.cs.cs167.mkim410.App 3 20 3v5